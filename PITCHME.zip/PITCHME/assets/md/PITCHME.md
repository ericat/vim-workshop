
## Do you even
<img class="cover" src="./assets/md/assets/cover.png" />
---
## Why hate Vim?
- counterintuitive  <!-- .element: class="fragment" -->
- learning wall  <!-- .element: class="fragment" -->
---
## The Learning Wall
_viewed 1,392,379 times_

<span class="menu-title" style="display: none">Quitting Vim</span>
![Image](./assets/md/assets/quitting-so.png)
<span style="font-size:0.5em">[Stack Overflow: Helping One Million Developers Exit Vim](https://stackoverflow.com/questions/11828270/how-to-exit-the-vim-editor)</span>

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++
<span class="menu-title" style="display: none">Quitting Vim</span>
![Image](./assets/md/assets/quitting.jpg)

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++
<span class="menu-title" style="display: none">Quitting Vim</span>
![Image](./assets/md/assets/trapped.jpg)
---
## Why learn Vim?
- you dislike the mouse  <!-- .element: class="fragment" -->
- context switch - it slows you down  <!-- .element: class="fragment" -->
- commands will just "work" elsewhere  <!-- .element: class="fragment" -->
- it sneakily opens  <!-- .element: class="fragment" -->
---
<span class="menu-title" style="display: none">Vim Usage</span>
![Image](./assets/md/assets/vim-usage.png)
<br />
<span style="font-size:0.5em">[2018 Developer Skills Report - HackerRank](http://research.hackerrank.com/developer-skills/2018/)</span>
---
## Vim Philosophy
<ul class="none">
  <li><i class="fa fa-hand-o-right" aria-hidden="true"> </i> "Vim grammar" (commands are self-documenting)</li>
  <li><i class="fa fa-hand-o-right" aria-hidden="true"> </i> Modes: normal, insert, visual, command.</li>
</ul>
---
## Where to Start
<div class="terminal">
  $ brew install vim
</div>

...what next?
---
## Configuration Time
- get Vundle  - install plugins with one command
- `touch ~/.vimrc`
- enable arrows in insert mode
- enable mouse
- remap ESC
---
## Your .vimrc
Edit directly from Vim:
```
:edit or :e $MYVIMRC
:source $MYVIMRC
```

Optional, but good to have:
```
alias vimrc='vi ~/.vimrc'
```

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++

<span class='menu-title slide-title'>Source: .vimrc</span>
```bash
set nocompatible
filetype off

" set the runtime path to include Vundle and initialize
set rtp+=~/.vim/bundle/Vundle.vim
call vundle#begin()

" Plugins
Plugin 'VundleVim/Vundle.vim'
Plugin 'alvan/vim-closetag'
Plugin 'bling/vim-airline'
Plugin 'ctrlpvim/ctrlp.vim'
Plugin 'mxw/vim-jsx'
Plugin 'pangloss/vim-javascript'
Plugin 'prettier/vim-prettier'
Plugin 'rking/ag.vim'
Plugin 'scrooloose/nerdcommenter'
Plugin 'scrooloose/nerdtree'
Plugin 'scrooloose/syntastic'
Plugin 'terryma/vim-multiple-cursors'
Plugin 'tpope/vim-commentary'
Plugin 'tpope/vim-surround'
Plugin 'hashivim/vim-terraform'
Plugin 'digitaltoad/vim-pug'

call vundle#end()            " required for Vundle
filetype plugin indent on    " required for Vundle

" Fix common misspellings
source ~/.vim/.abbreviations.vim

" Custom
syntax enable
syntax on
set encoding=utf-8
colorscheme molokai
let g:molokai_original = 1
imap jk <ESC>
let mapleader=" "
let g:closetag_filenames = "*.html,*.xhtml,*.phtml"
let g:jsx_ext_required = 0

set mouse=a                 " enable mouse
set path+=**/src/main/**,** " press gf within quotes in require('') to open that file
set suffixesadd+=.js        " files searched when gf (above)
set noswapfile              " disable swapfiles
set nobackup                " disable backups
set ttyfast                 " set faster rendering
set lazyredraw              " redraw only when we need to.
set list listchars=tab:\·\ ,trail:·        " mark whitespace with character
set laststatus=2            " always display statusline
" statusline settings
set statusline+=%F          " add path to statusline
set statusline+=%#warningmsg#
set statusline+=%{SyntasticStatuslineFlag()}
set statusline+=%*
set clipboard=unnamed       " access clipboard
set t_ut=                   " disable deleted colouring
set t_Co=256                " force 256 colour mode
set t_vb=                   " turn off bell
set noerrorbells            " turn of bell for realsies 
au FileType gitcommit set tw=72            " wrap long commit messages
set nowrap                  " no wrapping for lines longer than window
set shiftwidth=2            " smarttab values
set shiftround              " round indent to multiple of shiftwidth
set smarttab                " <tab> depends on value of shiftwidth
set tabstop=2               " number of spaces <tab> will count for
set softtabstop=2           " number of spaces <tab> counts while editing
set expandtab               " use <space>s rather than <tab>
set autoindent              " use current line indentation when copying
set scrolloff=3             " minimum lines before/after curso
set linebreak               " avoid wrapping line at inconvenient points
set hidden                  " don't complain about buffers
set number                  " show line number
set ruler                   " show ruler
set splitbelow              " set vertical splits to below
set splitright              " set horizontal splits to the right
set backspace=indent,eol,start             " backspace was not working anymore
set cursorline              " highlight line
set gdefault                " perform global substitutions by default
set autoread                " reload files if they have changed from within vim
set autowrite               " autosave when focus is lost
set autowriteall
set infercase               " smarter completions"
set showmatch               " show matching brace briefly
set hlsearch                " highlight all matches
set incsearch               " show pattern while typing
set ignorecase              " ignore the case of normal letters
set smartcase               " override ignorecase when searching with uppercase patterns
set runtimepath^=~/.vim/bundle/ctrlp.vim
set fileformat=unix
set wildmenu                " autosuggest on tab"
set wildmode=full
set wildignore+=node_modules/*
set shellcmdflag=-ic        " load interactive shell
set noerrorbells
set foldmethod=indent       "enable code folding based on indent
set nofoldenable            " prevent vim from opening files already folded

" comfort commands
command! -bar -bang Q quit<bang>
command! W w
command! WQ wq
command! Wq wq
command! Q q

" Theme, style, formatting, UI
autocmd BufWritePre *.js :%s/\s\+$//e       "remove trailing whitespace on save
autocmd BufNewFile,BufRead *.pcss set syntax=css
augroup CursorLine         " cursorLine function highlights line in active pane
  au!
  au VimEnter,WinEnter,BufWinEnter * setlocal cursorline
  au WinLeave * setlocal nocursorline
augroup END
" resize panes when vim is resized
au VimResized * exe "normal! \<c-w>="
" insert blank line above/below
nmap T O<ESC>j
nmap t o<ESC>k
" clear last search highlighting
map <Space> :noh<cr>
" highlight the current line
hi CursorLine cterm=NONE ctermbg=241

" Plugins
" ctrlp
let g:ctrlp_custom_ignore = {
    \ 'dir':  '\.git$\|public$|log\|tmp\|target$\|coverage\|node_modules$',
    \ 'file': '\.so$\|\.dat$|\.DS_Store$|\.log$|\.tar.gz$|.zip$|.swp$|\.lock$'
    \ }
let g:ctrlp_cache_dir = $HOME . '/.cache/ctrlp'
let g:ctrlp_max_files=0
let g:ctrlp_max_depth=40
let g:ctrlp_working_path_mode = 0

" silver searcher
let g:ackprg = 'ag --vimgrep'
if executable('ag')
  set grepprg=ag\ --nogroup\ --nocolor " Use Ag over Grep
  let g:ctrlp_user_command = 'ag %s -l --nocolor -g ""'
endif

" nerdtree
let g:NERDTreeHijackNetrw=0 " Prohibit NERDTree from spawning new panes
let g:NERDTreeWinPos = "left"
let NERDTreeShowHidden = 1
let g:NERDSpaceDelims = 1
nnoremap <C-t> :NERDTreeToggle<CR>
vnoremap . :norm.<CR>

" iterm
nnoremap <C-h> <C-w>h
nnoremap <C-j> <C-w>j
nnoremap <C-k> <C-w>k
nnoremap <C-l> <C-w>l
" Enable copy / paste from outside
vnoremap <C-c> "*y

" Delete, not cut!
vnoremap d "_d
nnoremap d "_d

" Disable annoying Type x to go to visual mode
nnoremap  Q <Nop>

```


<span class="code-presenting-annotation fragment current-only" data-code-focus="43">Enable mouse.</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="74">Show line number.</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="86">Highlight matches when searching</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="151-155">iTerm shortcuts.</span>
<span class="code-presenting-annotation fragment current-only" data-code-focus="159-161">Delete, not cut!</span>
---
## Exit Vim
```
:w
:q
:wq
:wa
```

Comfort settings:
```
command! -bar -bang Q quit<bang>
command! W w
command! WQ wq
command! Wq wq
command! Q q
```
---
## Vim Modes
- normal, *Esc*
- insert, *i*
- visual, *v*
- command, *:*
---
## Command Mode
- execute commands (:q, :vs, :wa)
- operate on word/line/ranges without moving the cursor (5,10d)
- interact with the command line (:source)

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++
Some examples:
```
:m17
:t17
:!ls // fg
```
---
## Selecting text
```
v // selects a character
V // selects line
o  // moves end / start selection
```

Other examples:
```
vw
vit
vi"
vi(
vt;
```
---
## Editing text
```
i, I // insert
c, C // change
a, A // append
o, O // open a line
```
---
## Deleting text
```
d, dd
d/vim
r // replace a char
x // delete a char
```
From insert mode:
```
Ctrl h // char
Ctrl w // word
Ctrl u // line
```
---
## Undo, Redo
It's simple!
```
u
Ctrl r
```
---
## Moving around
In a file
```
h j k l
w, b
%  // matching brackets
:n // move to line num
0 // beginning of line
$ // end of line
```

In the window:
```
H
M
L
```

With find:
```
f <char>
;
,
```
## Productivity
```
5u // undo 5 times
xp // swap characters
:sort
:12,15norm dit // norm command
Ctrl a, Ctrl x // increment / decrement
```

Open file at line 21:
```
vi +25 file.js -c d
```
---
## Pain points
<ul class="none">
  <li><i class="fa fa-thumbs-down" aria-hidden="true"> </i> Delete is actually cut</li>
  <li><i class="fa fa-thumbs-down" aria-hidden="true"> </i> Copy and paste can be tricky to setup</li>
  <li><i class="fa fa-thumbs-down" aria-hidden="true"> </i> Global search and replace</li>
  <li><i class="fa fa-thumbs-down" aria-hidden="true"> </i> Typos</li>
</ul>

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++
## When things go wrong

![Image](./assets/md/assets/prototcolpe.jpg)

<p class="error">:s/y/col</p>
<p class="success">:s/\&lt;y/&gt;/col</p>
---
## Resources
<ul class="none">
 <li><i class="fa fa-keyboard-o" aria-hidden="true"> </i> [Open Vim](http://www.openvim.com/tutorial.html)</li>
 <li><i class="fa fa-github-alt" aria-hidden="true"> </i> [Vim Galore](https://github.com/mhinz/vim-galore)</li>
 <li><i class="fa fa-link" aria-hidden="true"> </i> [Vim gifs](https://vimgifs.com/)</li>
 <li><i class="fa fa-link" aria-hidden="true"> </i> [Vim cheatsheet](https://vim.rtorr.com/)</li>
 <li><i class="fa fa-gamepad" aria-hidden="true"> </i> [Vim adventure](https://vim-adventures.com/)</li>
 <li><i class="fa fa-video-camera" aria-hidden="true"> </i> [Learn to Use Vim](https://egghead.io/courses/learn-to-use-vim)</li>
 <li><i class="fa fa-book" aria-hidden="true"> </i> [Mastering Vim](https://jovicailic.org/mastering-vim-quickly/)</li>
</ul>

<i class="fa fa-arrow-down" aria-hidden="true"> </i>

+++
<!-- .slide: data-background-image="./assets/md/assets/keyboard.jpg" data-background-size="100% 100%" -->

<span class="menu-title" style="display: none">Keyboard Cover</span>